To execute the code, You may simply run all cells in `PA2_code.ipynb`.
And the resulted mesh is `best_triangulation_result.ply` and its screenshot `Triangulation_result.png` is also included.